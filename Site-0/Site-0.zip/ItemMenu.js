

ItemMenu[ItemMenu.length]="liens";
listpagevision[listpagevision.length]=1;
Xtarget[Xtarget.length]='_top';
LienItemMenu[LienItemMenu.length]="pageA1.html";
TitreItemMenu[TitreItemMenu.length]="liens";

