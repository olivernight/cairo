﻿var Editpasici=new Array()
// pour créer un nouveau mot de passe recopiez la ligne et changer le mot de passe
Editpasici[Editpasici.length]="cartoici"
