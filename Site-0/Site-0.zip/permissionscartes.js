var listpubcartovision=new Array();var rangliste=new Array(); 
var REPmapXsite=new Array();

REPmapXsite[REPmapXsite.length]="FRANCE_REGIONS";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="PAYSdelaLOIRE";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="MONDE";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="PAYSdelaLOIRE2";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="BOURGOGNEatmp";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="BOURGOGNEdads1";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="BOURGOGNEmixte";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FRANCE_DEP_sante1";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE-2005-1-rjf";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE-2005-3-rjf";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE-2005-1_3-rjf";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE2";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE3";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="IRIS-villeurbanne";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="FranceZE-2005-2-rjf";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="NORDpasdeCALAIS";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="NORDpasdeCALAIS2";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="France-UNIFORMATION";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="EUROPE";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="ASIE_SUD_EST";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="ASIE";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="VIETNAM_Integration_61_provinces";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="VIETNAM_Integration_64_provinces";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="ASIE2";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="ASIE3";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="ASIE - 2";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

REPmapXsite[REPmapXsite.length]="TGI";
listpubcartovision[listpubcartovision.length]=0;
rangliste[rangliste.length]=1;

