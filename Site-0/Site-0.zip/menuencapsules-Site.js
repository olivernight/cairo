var listpubcartovision=new Array();var rangliste=new Array(); 
var menuencaps=new Array();

menuencaps[menuencaps.length]="Sommaire-Site-0";
listpubcartovision[listpubcartovision.length]=1;
rangliste[rangliste.length]=1;


