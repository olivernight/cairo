﻿<?php

$haut="<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" lang=\"fr-fr\">
<head>


  
<script language='javascript' src='REP.js'></script>
  
  <title>Page-".$n[1]."-site.htm</title>
  <meta http-equiv=\"Content-type\" content=\"text/html; charset=UTF-8\">

  
  <meta http-equiv=\"Content-Script-Type\" content=\"text/javascript\">

</head>


<body style=\"background-color: transparent\" >";



$bas="</body></html>";


?>